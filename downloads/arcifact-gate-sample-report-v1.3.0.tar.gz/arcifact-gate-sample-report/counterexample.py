"""Synthesise a checkable counterexample for a merge-gate finding.

A finding that says "job X sits outside the gate" is an assertion about
a graph. A counterexample is different in kind: it is a concrete world,
one result per job, in which X fails and the gate still reports success.
It can be read in ten seconds, argued with, and checked mechanically.

Nothing here is sampled or imagined. The world is constructed from the
finding, and the gate's own condition is then EVALUATED under it using
the same expression engine that decides predicate analysis. If the gate
does not come out green, no counterexample is emitted, because the
finding would not survive it.

That last property is the point. A tool that can always produce a
counterexample is producing decoration. This one produces nothing when
the world does not hold, which is what makes the ones it does produce
worth reading.
"""
import json
import re

import gexpr

RESULTS = ("success", "failure", "cancelled", "skipped")


def _blob(job):
    parts = [str(job.get("if", "") or ""), json.dumps(job.get("env", {}) or {})]
    for st in (job.get("steps") or []):
        if isinstance(st, dict):
            parts += [str(st.get("run", "")), str(st.get("if", "")),
                      json.dumps(st.get("env", {}) or {}),
                      json.dumps(st.get("with", {}) or {})]
    return " ".join(parts)


def _needs(job):
    n = job.get("needs") or []
    return [n] if isinstance(n, str) else list(n)


def _failure_steps(job):
    out = []
    for st in (job.get("steps") or []):
        if not isinstance(st, dict):
            continue
        run = str(st.get("run", "") or "")
        if re.search(r"\bexit\s+[1-9]", run) or "::error" in run:
            out.append(st)
    return out


def _accepted_values(blob):
    """Which dependency results does this gate treat as passing?

    Read off the comparison it actually writes, rather than assumed:
      != 'success'                 -> only success passes
      != 'success' and != 'skipped'-> success and skipped pass
      == 'failure'                 -> everything except failure passes
    Anything unrecognised returns None and the caller declines to model
    the gate at all."""
    strict = re.search(r"!=\s*['\"]success['\"]", blob)
    allows_skipped = re.search(r"!=\s*['\"]skipped['\"]", blob)
    only_failure = re.search(r"==\s*['\"]failure['\"]", blob)
    contains_fail = re.search(r"contains\s*\([^)]*['\"]failure['\"]", blob)
    if strict:
        return {"success", "skipped"} if allows_skipped else {"success"}
    if only_failure or contains_fail:
        acc = {"success", "skipped", "cancelled"}
        if re.search(r"['\"]cancelled['\"]", blob):
            acc.discard("cancelled")
        return acc
    return None


def _inspected(gate, blob):
    """The jobs whose results this gate actually reads. A generic gate
    iterating toJSON(needs) reads all of them."""
    if re.search(r"needs\.\*\.result|toJSON\(\s*needs", blob):
        return set(_needs(gate))
    return set(re.findall(r"needs\.([\w-]+)\.result", blob))


def gate_survives(gate, env, world):
    """Under this world, does the gate stay GREEN?

    A gate goes red when some step that can actually run inspects a job
    whose result it does not accept. Two things therefore have to hold
    for a step to matter: its own `if:` guard must be satisfiable in this
    world, and the values it rejects must include something present.

    Returns True for green, False for red, None when the gate cannot be
    modelled, in which case the caller emits nothing."""
    steps = _failure_steps(gate)
    if not steps:
        return True
    undecided = False
    for st in steps:
        cond = st.get("if")
        if cond not in (None, ""):
            ast = gexpr.parse(cond)
            if ast is None:
                undecided = True
                continue
            sat = gexpr.satisfiable(ast, env)
            if sat is None:
                undecided = True
                continue
            if not sat:
                continue                # guard cannot hold: step skipped
        blob = str(st.get("run", "")) + " " + str(st.get("if", "")) \
            + " " + json.dumps(gate.get("env", {}) or {})
        acc = _accepted_values(blob)
        looks = _inspected(gate, blob) or _inspected(gate, _blob(gate))
        if acc is None:
            undecided = True
            continue
        for j in looks:
            if world.get(j, "success") not in acc:
                return False            # this step fires: gate goes red
    return None if undecided else True


def synthesise(gate_id, gate, jobs, uncovered, producer=None,
               assume_outputs=None):
    """Build a world in which `uncovered` fails and the gate is green.

    The construction: every job the gate inspects succeeds, so nothing
    it looks at gives it a reason to fail; the uncovered job fails;
    anything downstream of the uncovered job is skipped, because GitHub
    does not run a job whose dependency failed. If a producer is named
    (the fail-open predicate case), its outputs are additionally empty,
    since a job that did not reach the step that sets them exposes
    nothing."""
    gneeds = _needs(gate)
    world = {}
    for j in jobs:
        world[j] = "success"
    world[uncovered] = "failure"

    # everything that depends on the failed job does not run
    changed = True
    while changed:
        changed = False
        for j, spec in jobs.items():
            if not isinstance(spec, dict) or world.get(j) == "failure":
                continue
            for n in _needs(spec):
                if world.get(n) in ("failure", "skipped") and world[j] != "skipped":
                    world[j] = "skipped"
                    changed = True

    env = {"always": "true"}
    for j, r in world.items():
        env[f"needs.{j}.result"] = r

    # A gate may branch on outputs of OTHER jobs, and a world that leaves
    # those free is undecidable rather than false. Both == and != count:
    # a guard written `is-trusted != 'true'` names the same value as one
    # written `== 'true'`, and only the first version of this harvester
    # matched equality, which left the ordinary path unmodelled. Where such a job
    # succeeded, take the value the gate compares it against: that is the
    # ordinary path, and it is the path the finding describes. Every such
    # assumption is recorded in the counterexample, so a reader can
    # reject the world rather than discover it was assumed.
    assumed = dict(assume_outputs or {})
    gblob = _blob(gate)
    for job, out, lit in re.findall(
            r"needs\.([\w-]+)\.outputs\.([\w-]+)\s*[!=]=\s*'([^']*)'", gblob):
        if job != producer and world.get(job) == "success":
            assumed.setdefault(f"{job}.{out}", lit)
    for key, val in assumed.items():
        env[f"needs.{key.replace('.', '.outputs.', 1)}"] = val

    if producer:
        blob = _blob(gate)
        for out in set(re.findall(rf"needs\.{re.escape(producer)}\.outputs\.([\w-]+)",
                                  blob)):
            env[f"needs.{producer}.outputs.{out}"] = ""

    survives = gate_survives(gate, env, world)
    if survives is not True:
        return None                     # the world does not hold: emit nothing

    # use the generic-aware reader: a gate iterating toJSON(needs)
    # reads all of them, and the raw regex finds none
    inspected = sorted(_inspected(gate, _blob(gate)))
    return {
        "kind": "counterexample",
        "gate": gate_id,
        "world": {k: v for k, v in sorted(world.items()) if k != gate_id},
        "failing_job": uncovered,
        "gate_result": "success",
        "checked_by": ("the gate's own condition, evaluated under this world "
                       "by the expression engine, not asserted"),
        "reads": inspected,
        "assumptions": (assumed or None),
        "narrative": (
            f"{uncovered} fails. "
            + (f"{producer} therefore exposes no outputs, so the gate's guard "
               f"cannot hold and its failure step is skipped. "
               if producer else
               f"The gate reads {', '.join(inspected) or 'nothing'}, none of "
               f"which is {uncovered}, so nothing it sees has changed. ")
            + f"{gate_id} reports success and the merge proceeds."),
    }
