"""Exact analysis of GitHub Actions `if:` expressions.

Arcifact Gate needs to answer one question precisely:

    if job P does not succeed, can this failure step still fire?

That is a satisfiability question, not a pattern match. A step guarded
by `needs.P.outputs.flag == 'true' && (...)` cannot fire when P fails,
because an unset output is the empty string. A step guarded by
`needs.P.outputs.flag != 'true' && (...)` still can. Regex cannot tell
those apart, and getting it backwards would be worse than not looking.

So this module parses the subset of the expression language that
appears in gate conditions, fixes every atom that depends on P to the
value it takes when P has failed, and then asks whether the remaining
formula is satisfiable over the free atoms.

If anything cannot be parsed, `parse` returns None and the caller
reports the condition as not analysed. Guessing is not an option here:
a wrong answer about a merge gate is worse than an absent one.

Supported: && || ! ( ) == != < <= > >= , string literals, numbers,
true/false/null, property paths (needs.x.result, needs.x.outputs.y,
github.event_name, steps.a.outputs.b, env.X), and the status functions
always() success() failure() cancelled(), plus contains(), startsWith(),
endsWith(), fromJSON(), toJSON() treated as opaque atoms.
"""

import itertools
import re

# ---------------------------------------------------------------- lexer

TOKEN = re.compile(r"""
    (?P<ws>\s+)
  | (?P<str>'(?:[^']|'')*')
  | (?P<num>-?\d+(?:\.\d+)?)
  | (?P<op>&&|\|\||==|!=|<=|>=|<|>|!|\(|\)|,|\[|\])
  | (?P<word>[A-Za-z_][\w.*\-]*)
""", re.X)


def _lex(s):
    out, i = [], 0
    while i < len(s):
        m = TOKEN.match(s, i)
        if not m:
            raise ValueError(f"unlexable at {i}: {s[i:i+18]!r}")
        i = m.end()
        kind = m.lastgroup
        if kind == "ws":
            continue
        out.append((kind, m.group()))
    return out


# --------------------------------------------------------------- parser
# Grammar (loosest to tightest):
#   or   := and ( '||' and )*
#   and  := cmp ( '&&' cmp )*
#   cmp  := unary ( ('=='|'!='|'<'|'<='|'>'|'>=') unary )?
#   unary:= '!' unary | primary
#   prim := '(' or ')' | call | literal | path

class P:
    def __init__(self, toks):
        self.t, self.i = toks, 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def eat(self, val=None):
        k, v = self.peek()
        if v is None:
            raise ValueError("unexpected end of expression")
        if val is not None and v != val:
            raise ValueError(f"expected {val!r}, got {v!r}")
        self.i += 1
        return (k, v)

    def parse(self):
        node = self.p_or()
        if self.i != len(self.t):
            raise ValueError(f"trailing tokens at {self.i}")
        return node

    def p_or(self):
        n = self.p_and()
        while self.peek()[1] == "||":
            self.eat()
            n = ("or", n, self.p_and())
        return n

    def p_and(self):
        n = self.p_cmp()
        while self.peek()[1] == "&&":
            self.eat()
            n = ("and", n, self.p_cmp())
        return n

    def p_cmp(self):
        n = self.p_unary()
        if self.peek()[1] in ("==", "!=", "<", "<=", ">", ">="):
            op = self.eat()[1]
            return ("cmp", op, n, self.p_unary())
        return n

    def p_unary(self):
        if self.peek()[1] == "!":
            self.eat()
            return ("not", self.p_unary())
        return self.p_primary()

    def p_primary(self):
        k, v = self.peek()
        if v == "(":
            self.eat("(")
            n = self.p_or()
            self.eat(")")
            return n
        if k == "str":
            self.eat()
            return ("lit", v[1:-1].replace("''", "'"))
        if k == "num":
            self.eat()
            return ("lit", v)
        if k == "word":
            self.eat()
            low = v.lower()
            if low in ("true", "false"):
                return ("lit", low)
            if low == "null":
                return ("lit", "")
            if self.peek()[1] == "(":            # function call
                self.eat("(")
                args, depth = [], 1
                start = self.i
                while depth:
                    kk, vv = self.peek()
                    if vv is None:
                        raise ValueError("unterminated call")
                    if vv == "(":
                        depth += 1
                    elif vv == ")":
                        depth -= 1
                        if depth == 0:
                            break
                    self.eat()
                inner = self.t[start:self.i]
                self.eat(")")
                return ("call", low, tuple(x[1] for x in inner))
            return ("path", v)
        raise ValueError(f"unparseable token {v!r}")


def parse(cond):
    """Parse a GitHub if-expression. Returns an AST, or None if the
    expression uses constructs this module does not model."""
    if cond is None:
        return None
    s = str(cond).strip()
    if s == "":
        return ("lit", "true")
    if s in ("true", "false"):
        return ("lit", s)
    # strip a single wrapping ${{ }} if present
    m = re.fullmatch(r"\$\{\{(.*)\}\}", s, re.S)
    if m:
        s = m.group(1).strip()
    if "${{" in s:            # interpolation inside the expression
        return None
    try:
        return P(_lex(s)).parse()
    except Exception:
        return None


# ------------------------------------------------------------ evaluation

TRUTHY_FALSE = ("", "false", "0")


def _truthy(v):
    return not (v is False or (isinstance(v, str) and v.lower() in TRUTHY_FALSE))


def atoms(node, acc=None):
    """Every leaf that carries a truth value: comparisons, bare paths and
    calls. These are what we quantify over."""
    if acc is None:
        acc = []
    if not isinstance(node, tuple):
        return acc
    tag = node[0]
    if tag in ("and", "or"):
        atoms(node[1], acc)
        atoms(node[2], acc)
    elif tag == "not":
        atoms(node[1], acc)
    elif tag in ("cmp", "path", "call"):
        if node not in acc:
            acc.append(node)
    return acc


def _value(node, env):
    """Value of a non-boolean sub-expression, as a string, or None if
    unknown."""
    if node[0] == "lit":
        return node[1]
    if node[0] == "path":
        return env.get(node[1])
    return None


def evaluate(node, env, free):
    """Truth of `node` given concrete `env` for known paths and a dict
    `free` assigning booleans to atoms whose value is not determined."""
    tag = node[0]
    if tag == "lit":
        return _truthy(node[1])
    if tag == "and":
        return evaluate(node[1], env, free) and evaluate(node[2], env, free)
    if tag == "or":
        return evaluate(node[1], env, free) or evaluate(node[2], env, free)
    if tag == "not":
        return not evaluate(node[1], env, free)
    if tag == "cmp":
        _, op, a, b = node
        va, vb = _value(a, env), _value(b, env)
        if va is None or vb is None:
            return free[node]
        if op == "==":
            return va == vb
        if op == "!=":
            return va != vb
        try:
            fa, fb = float(va), float(vb)
        except ValueError:
            return free[node]
        return {"<": fa < fb, "<=": fa <= fb,
                ">": fa > fb, ">=": fa >= fb}[op]
    if tag == "path":
        v = env.get(node[1])
        return free[node] if v is None else _truthy(v)
    if tag == "call":
        name = node[1]
        if name in env:
            return _truthy(env[name])
        return free[node]
    raise ValueError(f"cannot evaluate {tag}")


MAX_FREE = 20


def satisfiable(node, env):
    """Can `node` be true for SOME assignment of the atoms that `env`
    does not determine? Returns True, False, or None when the space is
    too large to decide exhaustively (never a guess)."""
    undecided = []
    for a in atoms(node):
        try:
            evaluate(a, env, {})
        except KeyError:
            undecided.append(a)
    if len(undecided) > MAX_FREE:
        return None
    for combo in itertools.product((False, True), repeat=len(undecided)):
        free = dict(zip(undecided, combo))
        try:
            if evaluate(node, env, free):
                return True
        except KeyError:
            return None
    return False


def env_for_failed_producer(producer, outputs=(), result="failure"):
    """The environment that holds when `producer` has not succeeded: its
    result is known, and every one of its outputs is the empty string,
    because outputs of a job that did not succeed are never set."""
    env = {f"needs.{producer}.result": result}
    for o in outputs:
        env[f"needs.{producer}.outputs.{o}"] = ""
    env["always"] = "true"
    return env


def referenced_outputs(text, producer):
    return sorted(set(re.findall(
        rf"needs\.{re.escape(producer)}\.outputs\.([\w-]+)", str(text))))


def producers_in(text):
    return sorted(set(re.findall(r"needs\.([\w-]+)\.outputs\.", str(text))))
