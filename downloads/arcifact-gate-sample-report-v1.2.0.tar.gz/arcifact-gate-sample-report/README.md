# Sample deliverable: Arcifact Gate

This is exactly what an Arcifact Gate review returns, on a synthetic
workflow, so you can see the deliverable and run the verifier before
sharing anything.

Nothing here describes a real repository. `example-org/example-service`
does not exist.

## What a review returns

    REPORT.pdf             the one-page finding, with what was NOT
                           established stated as prominently as what was
    record.json       the result, bound to the exact bytes analysed
    ci.yml                 the workflow those bytes are
    verify.py              reproduces the finding from the workflow
    verify_report.py       checks the INSTRUMENT behind the record
    verify_commitments.py  checks the commitment log itself
    report.schema.v1.json  the closed envelope schema
    commitments.json       the public append-only log at time of issue
    keys.json              the published issuer key
    EXPECTED-OUTPUT.txt    what all three verifiers print here
    CHECKSUMS.txt          digests of everything above

## Run it

### What you need

    minimum        Python 3.9+ and pyyaml
                   -> reproduces the finding and checks the chain
    --exercise     additionally jq, because the workflow's own predicate
                   uses it
    verify_report  additionally jsonschema (and rfc3339-validator) for
                   full envelope validation; without it the structure is
                   checked and the verdict says so
    signatures     additionally pynacl. Without it, a requested signature
                   check returns INCOMPLETE and a non-zero exit. It will
                   never report a log as authentic that it could not
                   check.

    pip install -r requirements.txt      # all of the above, pinned

    python3 verify.py ci.yml record.json --exercise

It should match the first section of `EXPECTED-OUTPUT.txt`. With
`--exercise` it goes further than reading the workflow: it runs the
gate's own failure step against constructed inputs and confirms the step
exits zero when every dependency passes and non-zero when one fails. A
gate that merely mentions `toJSON(needs)` is not a gate; this checks it
rejects a bad result.

Then check the instrument and the log:

    python3 verify_report.py record.json --commitments commitments.json --sources .
    python3 verify_commitments.py commitments.json --issuer-keys keys.json

The second refuses the record if the analyser that produced it was never
committed to the public log, or was committed only after the record
claims to have been issued. The third checks the log has not been
rewritten. The verifier binds the
certificate to the file's bytes, recomputes the seal, confirms the
gate's needs and how it aggregates, and for the flagged job checks that
it is not in the gate's needs, not reachable to the gate through the
needs graph, and has no dependent that the gate inspects. That last
check matters: a job whose failure reaches the gate indirectly is not a
gap, and the verifier proves this one does not.

No network access, and no Arcifact service or proprietary analyser is
required. The verifiers are Arcifact-authored, and they are supplied as
inspectable source precisely so you do not have to take them on trust:
read them, then run them against your own file.

## Try to break it

The verifier is built to fail, and you should confirm that:

    # add the job to the gate's needs, then rerun
    #   -> NOT CONFIRMED
    # change one byte of ci.yml, then rerun
    #   -> source sha256 differs, and it says so
    # edit record.json, then rerun
    #   -> the seal does not recompute

A verifier that always confirms is worthless.

## Check the instrument, not just the result

A result is only as good as the tool that produced it, and a tool that
can be edited between the bar being set and the result being published
is not an instrument, it is an opinion with a hash.

So this certificate names the exact bytes of the analyser that produced
it, and those bytes are committed to a public append-only log. Run:

    python3 verify_report.py record.json --commitments commitments.json

It refuses the record if the analyser was never committed, or was
committed only after the record claims to have been issued. Try it:
change a digit of any `tool_digests` value and rerun.

That rule binds me. I cannot quietly change what the analyser concludes
and reissue under the earlier reputation, because the digest would match
no prior entry. You can date any log head yourself against public git
history, which does not involve me at all.

## What the finding says, and what it does not

Says: `contract-tests` can run on pull requests and sits outside this
gate's closure, so its failure cannot change the gate's result. That is
a **proven structural gap**.

Does not say: that this gate is enforced. No required-check list was
supplied here, so the record carries `enforcement: unverified` and the
finding is deliberately NOT called a proven enforced merge gap. The bar
recorded in the public commitment log requires confirmed enforcement
before a finding earns that name, and this sample does not meet it.

Does not say: that `contract-tests` ought to block a merge. That is
your policy, not a fact about the file, and the certificate records it
as `unresolved` with the observation that would settle it.

This sample also carries `enforcement: unverified`, because no
required-check list was supplied. On a real review you supply that list
and the record states whether the gate is actually enforced. A job
named like a gate is a naming convention, never evidence.

## A real review

One workflow file, or a repository name if it is public. Optionally your
required-check list, which is the only thing that settles enforcement.
Static analysis only: nothing is executed, no repository access is
needed, and nothing is published without your written approval.

Ben Duncan, Arcifact Ltd, arcifact.io/gate
