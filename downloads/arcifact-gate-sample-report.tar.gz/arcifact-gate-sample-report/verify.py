#!/usr/bin/env python3
"""Independent verifier for the Arcifact Gate finding on
a GitHub Actions workflow.

This is the SAMPLE deliverable. It analyses a synthetic workflow so you
can see exactly what a real Arcifact Gate report contains and how you
would check it, without needing to share anything first.

    python3 verify.py run-tests.yml certificate.json

Run it against your own checkout instead, which is the point:

    python3 verify.py /path/to/.github/workflows/run-tests.yml certificate.json

No network access and no Arcifact code. Requires Python 3.9+ and pyyaml.

WHAT IT ESTABLISHES, from your file alone

  1. the certificate is bound to your exact file bytes;
  2. the certificate self-seal recomputes;
  3. the gate job's needs are exactly what the certificate says;
  4. how the gate aggregates: it declares
     RESULTS: ${{ toJSON(needs.*.result) }} at JOB level and fails if any
     value is not success, so it sees precisely the jobs in its needs
     and no others;
  5. for each job the certificate calls uncovered: that it exists, that
     it declares no job-level condition, that it is NOT in the gate's
     needs, that it is not reachable to the gate through the needs
     graph, and that no transitive dependent of it is inspected by the
     gate. The last point matters: a job whose failure reaches the gate
     indirectly is not a gap, and this verifier checks it does not.

No claim is made that either job has ever failed on a merged pull
request. That is recorded as unresolved in the certificate.
"""
import hashlib
import json
import re
import sys

import yaml

OK = "OK "
NO = "NOT CONFIRMED"


def needs_of(job):
    n = job.get("needs") or []
    return [n] if isinstance(n, str) else list(n)


def blob_of(job):
    """Every expression-bearing surface of a job, including its own env.
    Job-level env matters: this gate hoists toJSON(needs.*.result) there
    rather than into a step."""
    parts = [str(job.get("if", "") or ""),
             json.dumps(job.get("env", {}) or {})]
    for st in (job.get("steps") or []):
        if isinstance(st, dict):
            parts += [str(st.get("run", "")), str(st.get("if", "")),
                      json.dumps(st.get("env", {}) or {}),
                      json.dumps(st.get("with", {}) or {})]
    return " ".join(parts)


def main(wf_path, cert_path):
    raw = open(wf_path, "rb").read()
    cert = json.load(open(cert_path))
    ok = True

    got = hashlib.sha256(raw).hexdigest()
    if got == cert.get("source_sha256"):
        print(f"{OK} source sha256 matches the certificate")
    else:
        ok = False
        print(f"{NO} source sha256 differs")
        print(f"     certificate binds {cert.get('source_sha256')}")
        print(f"     your file is      {got}")
        print("     (the finding may still hold; this certificate "
              "describes different bytes)")

    body = {k: v for k, v in cert.items() if k != "sha256"}
    seal = hashlib.sha256(json.dumps(body, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()
    if seal == cert.get("sha256"):
        print(f"{OK} certificate seal recomputes")
    else:
        ok = False
        print(f"{NO} certificate seal does not recompute")

    doc = yaml.safe_load(raw)
    jobs = doc.get("jobs", {}) or {}
    pay = cert["payload"]
    gid = pay["gate"]["job_id"]
    if gid not in jobs:
        print(f"{NO} gate job {gid!r} not present in this file")
        print()
        print("VERDICT   NOT CONFIRMED (this file does not contain the "
              "gate the certificate describes)")
        return 1
    gate = jobs[gid]
    gneeds = needs_of(gate)
    gblob = blob_of(gate)

    same = sorted(gneeds) == sorted(pay["covered_jobs"])
    print(f"{OK if same else NO} gate needs match the certificate "
          f"({len(gneeds)} jobs: {', '.join(sorted(gneeds))})")
    ok = ok and same

    collective = bool(re.search(r"needs\.\*\.result|toJSON\(\s*needs", gblob))
    print(f"{OK if collective else NO} gate aggregates generically over its "
          f"needs (toJSON(needs.*.result))")
    print("     so it sees exactly the jobs in needs, and no others")
    ok = ok and collective

    succ = {j: set() for j in jobs}
    for j, s in jobs.items():
        if isinstance(s, dict):
            for n in needs_of(s):
                if n in succ:
                    succ[n].add(j)

    def dependents(a):
        out, stack = set(), [a]
        while stack:
            u = stack.pop()
            for v in succ.get(u, ()):
                if v not in out:
                    out.add(v)
                    stack.append(v)
        return out

    print()
    print("uncovered jobs claimed by the certificate:")
    bad = []
    for u in pay["uncovered_jobs"]:
        jid = u["job"]
        if jid not in jobs:
            print(f"  {jid:24s} NOT IN FILE")
            bad.append(jid)
            continue
        spec = jobs[jid]
        cond = spec.get("if")
        unconditional = cond is None or str(cond).strip() == ""
        in_needs = jid in gneeds
        deps = dependents(jid)
        reach = gid in deps
        indirect = deps & set(gneeds)
        outside = (not in_needs) and (not reach) and not indirect
        name = spec.get("name", jid)
        print(f"  {jid:24s} {'OUTSIDE THE GATE' if outside else 'COVERED'}"
              f"   (renders as {str(name)!r})")
        print(f"  {'':24s} job-level condition: "
              f"{'none' if unconditional else str(cond)[:56]}")
        print(f"  {'':24s} in gate needs: {in_needs}   reachable to gate: "
              f"{bool(reach)}   inspected dependents: "
              f"{sorted(indirect) or 'none'}")
        sev = "active, runs on every pull request" if unconditional \
            else "latent, runs only when its condition holds"
        print(f"  {'':24s} severity: {sev}")
        if not outside:
            bad.append(jid)
    print()
    if bad:
        print(f"VERDICT   NOT CONFIRMED ({len(bad)} job(s) could not be "
              f"shown outside the gate)")
        return 1
    print("VERDICT   " + ("CLOSURE GAP CONFIRMED" if ok
                          else "CONFIRMED, CERTIFICATE MISMATCH"))
    if ok:
        print("          Each listed job sits outside the gate's closure: "
              "not in its")
        print("          needs, not reachable to it, and with no inspected "
              "dependent.")
    print()
    print("A confirmed gap means the job is structurally outside the gate.")
    print("It does NOT mean the job ought to be inside it: that is your "
          "policy,")
    print("and the certificate records it as unresolved.")
    return 0 if ok else 1


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    raise SystemExit(main(sys.argv[1], sys.argv[2]))
