"""Repository-level merge closure, through reusable workflows.

Everything else in this project analyses one file. That is honest but
narrow, and it leaves two questions unanswerable.

FIRST: a job written `uses: ./.github/workflows/x.yml` is one node in
the caller and an entire graph in the callee. Single-file analysis can
only declare the subgraph unread. Worse, the caller job's success does
NOT imply every job in the callee passed: a callee job carrying
continue-on-error can fail while the caller stays green, so a required
check can be green with a test failed two files away. Nothing that reads
one file can see it.

SECOND: required contexts are repository-level, not file-level. Only a
whole-repository view can say that no workflow produces a required
context, or that two do, which is worse: two check runs sharing a name
make the requirement ambiguous.

Remote callees (`org/repo/.github/workflows/x.yml@ref`) are NOT fetched.
They are reported as unresolved, because analysing a file this run never
read would be exactly the assumption the project exists to refuse.
"""
import json
import os
import re

import yaml

MAX_DEPTH = 6

# Events that decide whether a pull request may merge. workflow_dispatch
# is manual and schedule is periodic, so two jobs sharing only those do
# not compete to satisfy a required check on a pull request.
MERGE_EVENTS = ("pull_request", "pull_request_target", "merge_group")

NONGATE = re.compile(r"cancel|notify|comment|label|report|coverage|upload"
                     r"|publish|slack|announce|cleanup|clean.?cache|pages",
                     re.I)


def trigger_events(doc):
    on = doc.get("on", doc.get(True))
    if isinstance(on, str):
        on = {on: None}
    if isinstance(on, list):
        on = {k: None for k in on}
    if not isinstance(on, dict):
        return set()
    return {str(k) for k in on}


def merge_events(doc):
    return trigger_events(doc) & set(MERGE_EVENTS)


def _is_telemetry(job_id, spec):
    """A publish, report or notify job is not validation. Marking one
    advisory is a deliberate choice, not a hidden failure."""
    return bool(NONGATE.search(job_id) or NONGATE.search(_check_name(job_id, spec)))


def gate_closure(doc, required):
    """Every job whose result can reach a job publishing a required
    context, following needs backwards. A hidden advisory outside this
    set cannot affect the merge decision, so reporting it would be
    noise."""
    jobs = doc.get("jobs") or {}
    roots = [j for j, s in jobs.items()
             if isinstance(s, dict) and _check_name(j, s) in set(required or [])]
    if not roots:
        return None                     # nothing required here: unknown
    seen, frontier = set(roots), list(roots)
    while frontier:
        cur = frontier.pop()
        spec = jobs.get(cur)
        if not isinstance(spec, dict):
            continue
        for n in _needs(spec):
            if n not in seen:
                seen.add(n)
                frontier.append(n)
    return seen




def load_all(dirpath):
    """Every workflow in a .github/workflows directory."""
    out = {}
    for fn in sorted(os.listdir(dirpath)):
        if not fn.endswith((".yml", ".yaml")):
            continue
        try:
            doc = yaml.safe_load(open(os.path.join(dirpath, fn), "rb").read())
        except Exception as exc:
            out[fn] = {"_unparsed": str(exc)[:90]}
            continue
        if isinstance(doc, dict):
            out[fn] = doc
    return out


def _needs(spec):
    n = spec.get("needs") or []
    return [n] if isinstance(n, str) else list(n)


def _advisory(spec):
    v = spec.get("continue-on-error")
    if v is True:
        return True
    if isinstance(v, str):
        return None if "${{" in v else v.strip().lower() == "true"
    return False


def _check_name(job_id, spec):
    return str(spec.get("name") or job_id)


def callee_ref(uses):
    """Resolve a `uses:` value to a local filename, or explain why not."""
    u = str(uses).strip()
    if u.startswith("./"):
        return {"local": os.path.basename(u.split("@")[0])}
    return {"remote": u, "reason": "not in this repository; not fetched"}


def hidden_advisories(doc, path_label):
    """Jobs inside a called workflow that cannot fail their caller.

    This is the finding single-file analysis cannot reach. The caller
    job goes green, the required check goes green, and a job that failed
    is two files away with continue-on-error on it."""
    out = []
    for j, spec in (doc.get("jobs") or {}).items():
        if not isinstance(spec, dict):
            continue
        adv = _advisory(spec)
        if adv is True:
            out.append({"job": j, "workflow": path_label,
                        "name": _check_name(j, spec), "resolved": True})
        elif adv is None:
            out.append({"job": j, "workflow": path_label,
                        "name": _check_name(j, spec), "resolved": False,
                        "note": "continue-on-error is templated; not resolved"})
    return out


def expand(dirpath, filename, seen=None, depth=0):
    """A caller's jobs, each annotated with the callee it delegates to.

    Recursive, with cycle detection: a workflow that calls itself, or a
    pair that call each other, terminates and is reported rather than
    hanging."""
    seen = set(seen or ())
    if filename in seen:
        return {"_cycle": f"{filename} is already on the call path"}
    if depth > MAX_DEPTH:
        return {"_depth": f"call depth exceeded {MAX_DEPTH}"}
    full = os.path.join(dirpath, filename)
    if not os.path.exists(full):
        return {"_missing": filename}
    doc = yaml.safe_load(open(full, "rb").read()) or {}
    seen = seen | {filename}
    nodes = {}
    for j, spec in (doc.get("jobs") or {}).items():
        if not isinstance(spec, dict):
            continue
        node = {"spec": spec, "callee": None, "unresolved": None,
                "advisories": []}
        if spec.get("uses"):
            ref = callee_ref(spec["uses"])
            if "local" in ref:
                sub = expand(dirpath, ref["local"], seen, depth + 1)
                if any(k.startswith("_") for k in sub):
                    node["unresolved"] = list(sub.values())[0]
                else:
                    node["callee"] = {"file": ref["local"], "jobs": sub}
                    cdoc = yaml.safe_load(
                        open(os.path.join(dirpath, ref["local"]), "rb").read()) or {}
                    node["advisories"] = hidden_advisories(cdoc, ref["local"])
            else:
                node["unresolved"] = ref["reason"] + f" ({ref['remote'][:60]})"
        nodes[j] = node
    return nodes


def producers(workflows):
    """Which job in which file publishes each check name."""
    table = {}
    for fn, doc in workflows.items():
        if not isinstance(doc, dict) or doc.get("_unparsed"):
            continue
        for j, spec in (doc.get("jobs") or {}).items():
            if isinstance(spec, dict):
                table.setdefault(_check_name(j, spec), []).append((fn, j))
    return table


def pr_capable(doc):
    on = doc.get("on", doc.get(True))
    if isinstance(on, str):
        on = {on: None}
    if isinstance(on, list):
        on = {k: None for k in on}
    if not isinstance(on, dict):
        return False
    return any(str(k).startswith("pull_request") for k in on)


def analyse(dirpath, required):
    """Repository-level findings that no single file can support."""
    wf = load_all(dirpath)
    table = producers(wf)
    req = [r.strip() for r in (required or []) if r.strip()]
    findings, notes = [], []

    for fn, doc in wf.items():
        if isinstance(doc, dict) and doc.get("_unparsed"):
            notes.append({"kind": "unparsed_workflow", "workflow": fn,
                          "error": doc["_unparsed"]})

    for r in req:
        hits = table.get(r) or [(f, j) for name, v in table.items()
                                for (f, j) in v
                                if name.startswith(r + " (")]
        if not hits:
            findings.append({
                "kind": "required_context_unproduced", "context": r,
                "severity": "active", "classification": "proven_gap",
                "reason": ("no job in any workflow in this repository "
                           "publishes this check name"),
                "consequence": ("the context can never report success, so "
                                "either the merge is blocked permanently or "
                                "the rule is stale")})
        elif len(hits) > 1:
            # Two producers are only ambiguous if they can BOTH fire on
            # the same merge-relevant event. A pull_request gate and a
            # merge_group gate publishing the same name is a deliberate
            # and correct pattern, and calling it ambiguous would be
            # exactly the noise this project criticises in others.
            overlap = set()
            for a in range(len(hits)):
                for b in range(a + 1, len(hits)):
                    ea = merge_events(wf[hits[a][0]])
                    eb = merge_events(wf[hits[b][0]])
                    overlap |= (ea & eb)
            if not overlap:
                notes.append({
                    "kind": "producers_on_disjoint_events", "context": r,
                    "producers": [f"{f}:{j}" for f, j in hits],
                    "events": {f: sorted(merge_events(wf[f])) for f, _ in hits},
                    "reason": ("more than one job publishes this name, but on "
                               "events that cannot both apply to one merge "
                               "decision. Not ambiguous.")})
                continue
            findings.append({
                "kind": "ambiguous_required_producer", "context": r,
                "shared_events": sorted(overlap),
                "producers": [f"{f}:{j}" for f, j in hits],
                "severity": "active", "classification": "proven_gap",
                "reason": ("more than one job publishes this check name, so "
                           "which run satisfies the requirement is not "
                           "determined by the configuration"),
                "consequence": ("a green requirement may reflect whichever "
                                "producer reported, not the one intended")})
        else:
            fn, j = hits[0]
            if not pr_capable(wf[fn]):
                findings.append({
                    "kind": "required_context_not_on_pull_request",
                    "context": r, "workflow": fn, "job": j,
                    "severity": "active", "classification": "proven_gap",
                    "reason": ("the only workflow publishing this context "
                               "does not trigger on pull_request"),
                    "consequence": ("the context cannot appear on a pull "
                                    "request from this repository")})

    for fn, doc in wf.items():
        if not isinstance(doc, dict) or doc.get("_unparsed"):
            continue
        nodes = expand(dirpath, fn)
        if any(k.startswith("_") for k in nodes):
            notes.append({"kind": "expansion_stopped", "workflow": fn,
                          "reason": list(nodes.values())[0]})
            continue
        closure = gate_closure(doc, req)
        pr_ok = bool(merge_events(doc) & {"pull_request", "pull_request_target"})
        for j, node in nodes.items():
            if closure is not None and j not in closure:
                continue        # cannot reach a required context here
            if not pr_ok:
                continue        # this workflow does not gate pull requests
            for a in node["advisories"]:
                if _is_telemetry(a["job"], {"name": a["name"]}):
                    notes.append({
                        "kind": "advisory_telemetry_in_callee",
                        "caller_workflow": fn, "callee_job": a["job"],
                        "reason": ("a publish, report or notify job marked "
                                   "advisory is a deliberate choice, not a "
                                   "hidden failure")})
                    continue
                findings.append({
                    "kind": "hidden_advisory_in_callee",
                    "caller_workflow": fn, "caller_job": j,
                    "callee_workflow": a["workflow"], "callee_job": a["job"],
                    "severity": "active",
                    "classification": ("proven_gap" if a["resolved"]
                                       else "unresolved_advisory"),
                    "reason": (f"{a['job']} in {a['workflow']} carries "
                               f"continue-on-error, so it cannot fail the "
                               f"caller job {j}"),
                    "consequence": ("a gate that inspects the caller sees "
                                    "success even when this job failed, and "
                                    "the failure is two files away"),
                    "fix": (f"remove continue-on-error from {a['job']}, or "
                            f"state in the callee that it is advisory")})
            if node["unresolved"]:
                notes.append({"kind": "callee_unresolved",
                              "workflow": fn, "job": j,
                              "reason": node["unresolved"]})
    return {"workflows": len(wf), "findings": findings, "notes": notes,
            "check_names": len(table)}


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    reqs = sys.argv[2].split(",") if len(sys.argv) > 2 else []
    print(json.dumps(analyse(sys.argv[1], reqs), indent=1))
