#!/usr/bin/env python3
"""Independent verifier for the Arcifact Gate finding on
a GitHub Actions workflow.

This is the SAMPLE deliverable. It analyses a synthetic workflow so you
can see exactly what a real Arcifact Gate report contains and how you
would check it, without needing to share anything first.

    python3 verify.py run-tests.yml record.json

Run it against your own checkout instead, which is the point:

    python3 verify.py /path/to/.github/workflows/run-tests.yml record.json

No network access and no Arcifact code. Requires Python 3.9+ and pyyaml.

WHAT IT ESTABLISHES, from your file alone

  1. the certificate is bound to your exact file bytes;
  2. the certificate self-seal recomputes;
  3. the gate job's needs are exactly what the certificate says;
  4. how the gate aggregates: it declares
     RESULTS: ${{ toJSON(needs.*.result) }} at JOB level and fails if any
     value is not success, so it sees precisely the jobs in its needs
     and no others;
  5. for each job the certificate calls uncovered: that it exists, that
     it declares no job-level condition, that it is NOT in the gate's
     needs, that it is not reachable to the gate through the needs
     graph, and that no transitive dependent of it is inspected by the
     gate. The last point matters: a job whose failure reaches the gate
     indirectly is not a gap, and this verifier checks it does not.

No claim is made that either job has ever failed on a merged pull
request. That is recorded as unresolved in the certificate.
"""
import hashlib
import json
import re
import sys

import yaml

OK = "OK "
NO = "NOT CONFIRMED"


def needs_of(job):
    n = job.get("needs") or []
    return [n] if isinstance(n, str) else list(n)


def blob_of(job):
    """Every expression-bearing surface of a job, including its own env.
    Job-level env matters: this gate hoists toJSON(needs.*.result) there
    rather than into a step."""
    parts = [str(job.get("if", "") or ""),
             json.dumps(job.get("env", {}) or {})]
    for st in (job.get("steps") or []):
        if isinstance(st, dict):
            parts += [str(st.get("run", "")), str(st.get("if", "")),
                      json.dumps(st.get("env", {}) or {}),
                      json.dumps(st.get("with", {}) or {})]
    return " ".join(parts)



def aggregation_semantics(gate, exercise=False):
    """Does the gate actually FAIL when a dependency fails?

    Finding toJSON(needs) in a job proves only that the aggregate is in
    scope. It does not prove the shell that consumes it rejects a bad
    result. A placeholder predicate would satisfy a presence check and
    reject nothing, so this checks three things statically:

      consumes   the failure step reads the aggregated value;
      exits      it has a reachable non-zero exit;
      selects    it discriminates on .result rather than exiting
                 unconditionally.

    Static analysis cannot prove a shell program correct. With
    --exercise the verifier goes further and RUNS the step's script
    against constructed inputs, asserting it exits zero when every
    dependency succeeded and non-zero when one failed. That is off by
    default because running a script from a workflow file is a decision
    the reader should make deliberately."""
    import re as _re, subprocess, tempfile, os as _os
    findings = {"consumes": False, "exits": False, "selects": False,
                "exercised": None, "step": None}
    for st in (gate.get("steps") or []):
        if not isinstance(st, dict):
            continue
        run = str(st.get("run", "") or "")
        env = json.dumps(st.get("env", {}) or {})
        if not run:
            continue
        aggregated = bool(_re.search(r"toJSON\(\s*needs", env + str(gate.get("env", {}))))
        var = None
        m = _re.search(r'"(\w+)"\s*:\s*"\$\{\{\s*toJSON\(\s*needs\s*\)', env)
        if m:
            var = m.group(1)
        consumes = bool(var and _re.search(rf"\${{?{var}\b", run))
        exits = bool(_re.search(r"exit\s+[1-9]", run))
        selects = bool(_re.search(r"\.result", run) or "select(" in run)
        if consumes and exits:
            findings.update({"consumes": consumes, "exits": exits,
                             "selects": selects,
                             "step": st.get("name", "(unnamed)")})
            if exercise:
                findings["exercised"] = _exercise(run, var)
            break
    return findings


def _exercise(script, var):
    """Run the gate's own failure script against constructed inputs.

    THIS EXECUTES SHELL WRITTEN IN THE WORKFLOW. It is only reached when
    the source binding and the certificate seal have both verified, so
    the code being run is the code the certificate describes and whose
    digest you can check. Even then it is contained:

      - a minimal environment: PATH, HOME and the aggregate variable
        only. The caller's environment, including any secrets, is not
        inherited.
      - an empty temporary working directory, removed afterwards, so the
        script cannot see or disturb your files by relative path.
      - a short timeout.

    This is containment, not a sandbox. It does not prevent network
    access or absolute-path writes. If that matters for a workflow you
    do not trust, read the script first: it is printed above, and
    --exercise is off by default precisely so this is your decision."""
    import subprocess, tempfile, shutil, os as _os
    good = '{"a":{"result":"success"},"b":{"result":"skipped"}}'
    bad = '{"a":{"result":"success"},"b":{"result":"failure"}}'
    out = {}
    workdir = tempfile.mkdtemp(prefix="arcifact-exercise-")
    try:
        for label, payload, want_zero in (("all-pass", good, True),
                                          ("one-failure", bad, False)):
            env = {"PATH": _os.environ.get("PATH", "/usr/bin:/bin"),
                   "HOME": workdir, var: payload}
            try:
                r = subprocess.run(["sh", "-c", script], env=env,
                                   cwd=workdir, capture_output=True,
                                   timeout=20)
                good_exit = (r.returncode == 0) if want_zero \
                    else (r.returncode != 0)
                out[label] = {"exit": r.returncode,
                              "as_expected": good_exit}
            except Exception as exc:
                out[label] = {"error": str(exc)[:60]}
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
    return out



def recompute_counterexample(gate_id, gate, jobs, record):
    """Rebuild the counterexample from YOUR file and compare.

    The record ships a world in which the flagged job fails and the gate
    is green. Reading it is one thing; deriving it again from the
    workflow in front of you is another, and it is the only version
    worth trusting. counterexample.py is included for exactly this, so
    the world is recomputed rather than believed."""
    try:
        import counterexample as ce
    except ImportError:
        print("     counterexample not recomputed: counterexample.py and "
              "gexpr.py are not beside this verifier")
        return None
    claimed = (record.get("payload") or {}).get("counterexamples") or []
    if not claimed:
        return None
    ok = True
    for c in claimed:
        mine = ce.synthesise(gate_id, gate, jobs, c["failing_job"],
                             producer=c.get("assumptions") and None)
        if mine is None:
            print(f"{NO} counterexample for {c['failing_job']!r} does NOT "
                  f"reproduce from this file")
            ok = False
            continue
        same = mine["world"] == c["world"] and mine["gate_result"] == c["gate_result"]
        print(f"{OK if same else NO} counterexample for {c['failing_job']!r} "
              f"{'reproduces exactly' if same else 'differs from the record'}")
        print(f"     {c['narrative'][:150]}")
        ok = ok and same
    return ok


def main(wf_path, record_path, exercise=False):
    raw = open(wf_path, "rb").read()
    cert = json.load(open(record_path))
    ok = True

    got = hashlib.sha256(raw).hexdigest()
    bindings = cert.get("source_bindings") or []
    bound = bindings[0].get("sha256") if bindings else cert.get("source_sha256")
    if got == bound:
        print(f"{OK} source sha256 matches the certificate")
    else:
        ok = False
        print(f"{NO} source sha256 differs")
        print(f"     certificate binds {bound}")
        print(f"     your file is      {got}")
        print("     (the finding may still hold; this certificate "
              "describes different bytes)")

    body = {k: v for k, v in cert.items() if k != "sha256"}
    seal = hashlib.sha256(json.dumps(body, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()
    if seal == cert.get("sha256"):
        print(f"{OK} certificate seal recomputes")
    else:
        ok = False
        print(f"{NO} certificate seal does not recompute")

    doc = yaml.safe_load(raw)
    jobs = doc.get("jobs", {}) or {}
    pay = cert["payload"]
    gid = pay["gate"]["job_id"]
    if gid not in jobs:
        print(f"{NO} gate job {gid!r} not present in this file")
        print()
        print("VERDICT   NOT CONFIRMED (this file does not contain the "
              "gate the certificate describes)")
        return 1
    gate = jobs[gid]
    gneeds = needs_of(gate)
    gblob = blob_of(gate)

    same = sorted(gneeds) == sorted(pay["covered_jobs"])
    print(f"{OK if same else NO} gate needs match the certificate "
          f"({len(gneeds)} jobs: {', '.join(sorted(gneeds))})")
    ok = ok and same

    collective = bool(re.search(r"needs\.\*\.result|toJSON\(\s*needs", gblob))
    print(f"{OK if collective else NO} gate aggregates over its needs "
          f"(toJSON(needs)), so it sees exactly those jobs")
    ok = ok and collective

    # HARD PRECONDITION. Executing shell out of a workflow whose bytes
    # do not match the certificate means running code the record does
    # not describe. An earlier version did exactly that, which is the
    # trust-boundary failure this project exists to catch.
    may_exercise = exercise and ok
    if exercise and not ok:
        print(f"{NO} --exercise REFUSED: the source binding or seal did "
              f"not verify, so the workflow is not the one this "
              f"certificate describes and its shell will not be run")
    sem = aggregation_semantics(gate, exercise=may_exercise)
    good = sem["consumes"] and sem["exits"] and sem["selects"]
    print(f"{OK if good else NO} its failure step actually rejects a bad "
          f"result")
    print(f"     step {sem['step']!r}: consumes the aggregate="
          f"{sem['consumes']}, discriminates on .result={sem['selects']}, "
          f"has a non-zero exit={sem['exits']}")
    if sem["exercised"]:
        for k, v in sem["exercised"].items():
            print(f"     exercised {k}: exit {v.get('exit')} "
                  f"{'as expected' if v.get('as_expected') else 'UNEXPECTED'}")
        good = good and all(v.get("as_expected")
                            for v in sem["exercised"].values())
    else:
        print("     not exercised: pass --exercise to run the step's own "
              "script against constructed inputs")
    ok = ok and good

    succ = {j: set() for j in jobs}
    for j, s in jobs.items():
        if isinstance(s, dict):
            for n in needs_of(s):
                if n in succ:
                    succ[n].add(j)

    def dependents(a):
        out, stack = set(), [a]
        while stack:
            u = stack.pop()
            for v in succ.get(u, ()):
                if v not in out:
                    out.add(v)
                    stack.append(v)
        return out

    cxok = recompute_counterexample(gid, gate, jobs, cert)
    if cxok is False:
        ok = False

    print()
    print("uncovered jobs claimed by the certificate:")
    bad = []
    for u in pay["uncovered_jobs"]:
        jid = u["job"]
        if jid not in jobs:
            print(f"  {jid:24s} NOT IN FILE")
            bad.append(jid)
            continue
        spec = jobs[jid]
        cond = spec.get("if")
        unconditional = cond is None or str(cond).strip() == ""
        in_needs = jid in gneeds
        deps = dependents(jid)
        reach = gid in deps
        indirect = deps & set(gneeds)
        outside = (not in_needs) and (not reach) and not indirect
        name = spec.get("name", jid)
        print(f"  {jid:24s} {'OUTSIDE THE GATE' if outside else 'COVERED'}"
              f"   (renders as {str(name)!r})")
        print(f"  {'':24s} job-level condition: "
              f"{'none' if unconditional else str(cond)[:56]}")
        print(f"  {'':24s} in gate needs: {in_needs}   reachable to gate: "
              f"{bool(reach)}   inspected dependents: "
              f"{sorted(indirect) or 'none'}")
        sev = "active, runs on every pull request" if unconditional \
            else "latent, runs only when its condition holds"
        print(f"  {'':24s} severity: {sev}")
        if not outside:
            bad.append(jid)
    print()
    if bad:
        print(f"VERDICT   NOT CONFIRMED ({len(bad)} job(s) could not be "
              f"shown outside the gate)")
        return 1
    if not ok:
        print("VERDICT   NOT CONFIRMED")
        print("          The structural gap held for the file as read, but "
              "this file or")
        print("          certificate is not the pair the record describes. "
              "Nothing here")
        print("          should be relied on until the binding and seal "
              "verify.")
        return 1
    print("VERDICT   CLOSURE GAP CONFIRMED")
    if True:
        print("          Each listed job sits outside the gate's closure: "
              "not in its")
        print("          needs, not reachable to it, and with no inspected "
              "dependent.")
    print()
    print("A confirmed gap means the job is structurally outside the gate.")
    print("It does NOT mean the job ought to be inside it: that is your "
          "policy,")
    print("and the certificate records it as unresolved.")
    return 0 if ok else 1


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    raise SystemExit(main(sys.argv[1], sys.argv[2],
                          exercise="--exercise" in sys.argv))
