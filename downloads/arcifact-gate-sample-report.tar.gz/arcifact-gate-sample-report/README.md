# Sample deliverable: Arcifact Gate

This is exactly what an Arcifact Gate review returns, on a synthetic
workflow, so you can see the deliverable and run the verifier before
sharing anything.

Nothing here describes a real repository. `example-org/example-service`
does not exist.

## What a review returns

    REPORT.pdf           one page: the finding, the evidence, the fix,
                         and what was NOT established
    certificate.json     the result bound to the exact bytes analysed
    verify.py            an independent verifier you run yourself
    ci.yml               the exact workflow bytes the certificate binds
    EXPECTED-OUTPUT.txt  what the verifier prints for this sample

## Run it

Requires Python 3.9 or later and pyyaml (`pip install pyyaml`).

    python3 verify.py ci.yml certificate.json

It should match `EXPECTED-OUTPUT.txt`. The verifier binds the
certificate to the file's bytes, recomputes the seal, confirms the
gate's needs and how it aggregates, and for the flagged job checks that
it is not in the gate's needs, not reachable to the gate through the
needs graph, and has no dependent that the gate inspects. That last
check matters: a job whose failure reaches the gate indirectly is not a
gap, and the verifier proves this one does not.

No network access. None of my code is trusted: the verifier reads your
file and recomputes everything.

## Try to break it

The verifier is built to fail, and you should confirm that:

    # add the job to the gate's needs, then rerun
    #   -> NOT CONFIRMED
    # change one byte of ci.yml, then rerun
    #   -> source sha256 differs, and it says so
    # edit certificate.json, then rerun
    #   -> the seal does not recompute

A verifier that always confirms is worthless.

## What the finding says, and what it does not

Says: `contract-tests` runs on pull requests and sits outside the
required gate's closure, so its failure cannot change the gate's
result.

Does not say: that `contract-tests` ought to block a merge. That is
your policy, not a fact about the file, and the certificate records it
as `unresolved` with the observation that would settle it.

This sample also carries `enforcement: unverified`, because no
required-check list was supplied. On a real review you supply that list
and the record states whether the gate is actually enforced. A job
named like a gate is a naming convention, never evidence.

## A real review

One workflow file, or a repository name if it is public. Optionally your
required-check list, which is the only thing that settles enforcement.
Static analysis only: nothing is executed, no repository access is
needed, and nothing is published without your written approval.

Ben Duncan, Arcifact Ltd, arcifact.io/gate
